import re
import math
import random

NetworkTable = {
					"MAC":[],
			   }


def get_new_mac():
	return "AB:CD:EF:%s:%s:%s" % (random.randint(10,99) ,random.randint(10,99),random.randint(10,99))


class InvalidMAC(Exception):
	def __init__(self,msg = ""):
		super(InvalidMAC, self).__init__()
		self.arg = msg

	def __str__(self):
		return self.arg
		
class MAC(object):
	__addr = ""
	_patrn = r"^([A-F0-9][A-F0-9])\:([A-F0-9][A-F0-9])\:([A-F0-9][A-F0-9])"+\
				"\:([A-F0-9][A-F0-9])\:([A-F0-9][A-F0-9])\:([A-F0-9][A-F0-9])$"
	def __init__(self, arg):
		super(MAC, self).__init__()
		m = re.match(self._patrn,\
					arg, re.IGNORECASE)
		if arg == "" or m is None:
			raise InvalidMAC("mac address is not valid")
		else: 
			if not arg in NetworkTable["MAC"]:
				self.__addr = arg
				NetworkTable["MAC"].append(arg)
			else:
				raise Exception("MAC address already present")

	def Address(self):
		return self.__addr

class EthernetFrame(object):

	__preamble = "10101010"*7
	__sof = "1"

	def __init__(self,dst_mac,src_mac,ether_type):
		super(EthernetFrame, self).__init__()


class DeviceNode(object):

	Address = None

	def __init__(self):
		super(DeviceNode, self).__init__()
		self.Address = MAC(get_new_mac()).Address()


	def Output(self,t):
		pass

x = DeviceNode()
print(x.Address)