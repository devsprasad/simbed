

class DummyClass(object):
	
	def __init__(self):
		super(DummyClass, self).__init__()
	
	def tes(self,t):
		return 0	