# simbed
A simulink-like <b>dynamic system simulation</b> environment developed in .NET with IronPython engine embedded in it to provide extensibility.

